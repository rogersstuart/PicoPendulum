#include "control.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "drv8833.h"
#include "debug.h"
#include "virtual_encoder.h"
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/pwm.h"

// Ensure M_PI is defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// External access to motor driver for PWM frequency control and protection status
extern drv8833_t drv;

// External motor inversion flag
extern bool MOTOR_INVERT;

// External sensor inversion flag  
extern bool SENSOR_INVERT;

static inline float clampf(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
static inline float sgn(float x) {
    if (x >  0.f) return  1.f;
    if (x <  0.f) return -1.f;
    return 0.f;
}
static inline float wrap_pi(float x) {
    while (x > M_PI)  x -= 2*M_PI;
    while (x <= -M_PI) x += 2*M_PI;
    return x;
}

// Global virtual encoder for unwrapped angle tracking.  On both the PC and
// Pi Pico builds the encoder is advanced each control loop with the
// measured angular velocity and the control timestep.  This allows rotation
// detection and predictive queries to mirror the PC simulator’s behaviour.
//
// Note: Initialisation of this encoder is performed in ctrl_init(), and the
// encoder state is updated in ctrl_update() during the swing‑up state.  By
// using the same C API on both platforms we maximise code reuse.
static VirtualEncoder ve;

// Thresholds for stationary detection (radians and rad/s)
static const float STATIONARY_ANGLE  = 0.05f;   // ≈3°
static const float STATIONARY_SPEED  = 0.05f;   // rad/s
static const float MOVE_THRESHOLD    = 0.035f;  // ≈2° – triggers end of breakaway

// Duty cycle for initial breakaway (full-on)
static const float BREAKAWAY_DUTY    = 0.8f;

void ctrl_init(ctrl_params_t *p, ctrl_state_t *s) {
    s->theta_b = 0.f;
    s->theta_u = 0.f;
    s->omega   = 0.f;
    s->u = 0.f;
    s->ui = 0.f;
    s->E = 0.f;
    s->Edes = 0.f; // Will be set later when parameters are configured
    s->state = ST_IDLE;  // Start in IDLE, not CALIB
    
    // Initialize new breakaway/drive variables
    s->kick_active    = false;
    s->kick_direction = 1;     // arbitrary start direction
    s->drive_level    = INITIAL_DRIVE_LEVEL;  // From config.h

    // Initialize new energy prediction and overshoot estimation variables
    s->energy_bleed_gain = 1.0f;        // Start with default gain
    s->last_apex_angle = 0.0f;          // No previous apex
    s->last_omega_sign = 0.0f;          // No previous velocity sign
    s->adaptive_brake_duty = 0.0f;      // No braking initially
    s->apex_detected_this_cycle = false; // No apex detected yet
    s->continuous_rotations = 0;        // No rotations counted yet

    // Initialise the virtual encoder.  The upright‑referenced angle (0 rad at
    // upright) is used as the reference.  At startup the pendulum is
    // assumed to be hanging down, so theta_u ≈ −π.  However, s->theta_u is
    // currently initialised to 0; the exact value will be set in main.c
    // before the first call to ctrl_update().  Initialising the encoder to
    // zero here is acceptable because the unwrapped angle will be updated
    // based on s->omega in ctrl_update().  If a more accurate initial
    // reference is needed (e.g. after calibration), ve_init can be called
    // again with a specific angle.
    ve_init(&ve, 0.0f);
}

void ctrl_reset_integrator(ctrl_state_t *s) { 
    s->ui = 0.f; 
    s->kick_active = false;
    s->drive_level = INITIAL_DRIVE_LEVEL; // From config.h
    // Keep energy prediction state during integrator reset
}

static float energy_control(const ctrl_params_t *p, ctrl_state_t *s) {
    /*
     * Swing‑up energy control using the upright‑referenced angle.  This implementation
     * mirrors the logic used in the PC simulator to ensure consistent behaviour
     * across platforms.  The total energy is computed relative to the hanging
     * position using the upright angle theta_u.  A breakaway kick is applied
     * when the pendulum is stuck at the bottom.  During normal swinging the
     * controller pumps energy into the system in the direction of motion and
     * adapts the drive level when subsequent peaks fail to increase.
     */

    // Convert upright angle to bottom‑referenced angle for rest detection
    float theta_b = wrap_pi(s->theta_u + (float)M_PI);

    // Safety: reset NaN angular velocity
    if (isnan(s->omega)) {
        s->omega = 0.0f;
        if (debug_is_output_enabled()) {
            printf("WARNING: omega was NaN, reset to 0.0\n");
        }
    }

    // Compute total energy relative to the hanging position using theta_u
    float cos_theta_u = cosf(s->theta_u);
    float J = CALCULATE_MOMENT_OF_INERTIA(p->m, p->L, p->Jm); // From config.h
    s->E = 0.5f * J * s->omega * s->omega +
           p->m * GRAVITY_ACCEL * (p->L * 0.5f) * (1.0f + cos_theta_u);
    float e = s->E - s->Edes;

    // Thresholds for detecting near‑rest conditions - from config.h
    const float STATIONARY_ANGLE  = STATIONARY_ANGLE_THRESHOLD;
    const float STATIONARY_SPEED  = STATIONARY_SPEED_THRESHOLD;  
    const float MOVE_THRESHOLD    = MOVEMENT_THRESHOLD;

    // Determine if the pendulum is nearly hanging (bottom) and barely moving
    bool at_rest = (fabsf(theta_b) < STATIONARY_ANGLE) && (fabsf(s->omega) < STATIONARY_SPEED);

    float u_energy = 0.0f;

    if (e < 0.0f) {
        // Below target energy: pump energy into the system
        if (s->kick_active) {
            // Continue applying breakaway impulse until motion is detected
            u_energy = BREAKAWAY_DUTY * (float)s->kick_direction;
            if (fabsf(theta_b) >= MOVE_THRESHOLD || fabsf(s->omega) >= STATIONARY_SPEED) {
                // End breakaway when the pendulum starts moving
                s->kick_active = false;
                s->drive_level = INITIAL_DRIVE_LEVEL;
                if (debug_is_output_enabled()) {
                    printf("BREAKAWAY->DRIVE: Motion detected, switching to continuous drive\n");
                }
            }
        } else if (at_rest) {
            // Pendulum is stuck at the bottom – start a kick
            if (fabsf(theta_b) > STATIONARY_ANGLE) {
                // Push away from the bottom if off‑centre
                s->kick_direction = -sgn(theta_b);
            } else {
                // Otherwise alternate direction
                s->kick_direction = -s->kick_direction;
            }
            s->kick_active = true;
            u_energy = BREAKAWAY_DUTY * (float)s->kick_direction;
            if (debug_is_output_enabled()) {
                printf("STARTING BREAKAWAY: direction=%d, duty=%.2f\n", s->kick_direction, BREAKAWAY_DUTY);
            }
        } else {
            // Pendulum is swinging: pump energy in the direction of motion
            float direction = sgn(s->omega);
            u_energy = s->drive_level * direction;
            
            // Static variables to track swing peaks for adaptive drive
            static float prev_peak = 0.0f;
            static float current_peak = 0.0f;
            static float last_omega_sign = 0.0f;

            current_peak = fmaxf(current_peak, fabsf(theta_b));
            float omega_sign = sgn(s->omega);
            if (omega_sign != last_omega_sign && last_omega_sign != 0.0f) {
                // End of half swing – compare peaks
                if (current_peak < prev_peak + 0.01f) {
                    // Peak did not increase – gently increase drive level
                    s->drive_level = fminf(s->drive_level + 0.05f, 0.8f);
                    if (debug_is_output_enabled()) {
                        printf("DRIVE-ADAPT: peak %.3f < prev %.3f, increasing drive_level to %.2f\n", 
                               current_peak, prev_peak, s->drive_level);
                    }
                }
                prev_peak = current_peak;
                current_peak = 0.0f;
            }
            last_omega_sign = omega_sign;

            if (debug_is_output_enabled() && ((int)(s->E * 100) % 50) == 0) {
                printf("CONTINUOUS-DRIVE: omega=%.3f, direction=%.1f, drive_level=%.2f, u=%.3f\n", 
                       s->omega, direction, s->drive_level, u_energy);
            }
        }
    } else {
        // At or above target energy – coast until catch logic takes over
        u_energy = 0.0f;
        s->kick_active = false;
        if (debug_is_output_enabled() && ((int)(s->E * 100) % 50) == 0) {
            printf("COASTING: E=%.3f >= Edes=%.3f\n", s->E, s->Edes);
        }
    }

    // Limit command to swing‑up saturation to avoid over‑driving the motor
    if (u_energy > p->swing_sat) {
        u_energy = p->swing_sat;
    } else if (u_energy < -p->swing_sat) {
        u_energy = -p->swing_sat;
    }

    s->u = u_energy;
    return u_energy;
}

float ctrl_update(ctrl_params_t *p, ctrl_state_t *s) {
    // Calculate physical parameters
    float J = (p->m * p->L * p->L) / 3.0f + p->Jm;
    // Compute energy using upright‑referenced angle (theta_u)
    float cos_theta_u = cosf(s->theta_u);
    s->E = 0.5f * J * s->omega * s->omega + p->m * 9.81f * (p->L * 0.5f) * (1.0f + cos_theta_u);
    // FIXED: Don't overwrite Edes - let main.c set it with 10% extra energy for swing-up
    // s->Edes = p->m * 9.81f * p->L; // REMOVED: This was overwriting the swing-up target
    
    // CRITICAL FIX: Use the Kalman estimate s->theta_u directly instead of overwriting it
    // The Kalman filter provides theta_u (angle from upright), so don't recalculate it
    // s->theta_u = s->theta_b - M_PI;  // REMOVED: Let Kalman estimate be used
    
    // Ensure theta_u is properly wrapped for control
    s->theta_u = wrap_pi(s->theta_u);
    
    float u = 0.0f;
    
    // State transition logic using robust upright detection
    bool is_upright = (fabsf(s->theta_u) < p->theta_catch) && (fabsf(s->omega) < p->omega_catch);
    /*
     * Detect when the pendulum is near the hanging (downward) position.  In the upright‑
     * referenced coordinate system theta_u, cos(theta_u) is −1 at the bottom and +1 at
     * the top.  A value less than −0.95 corresponds to being within about 18° of the
     * bottom.  Use cos_theta_u computed above to avoid undefined variables.
     */
    bool is_hanging = (cos_theta_u < -0.95f);

    // Force swing-up mode if not near upright
    if (s->state == ST_BALANCE && !is_upright) {
        s->state = ST_SWINGUP;
        if (debug_is_output_enabled()) {
            printf("BALANCE->SWINGUP: Lost balance (theta_u=%.3f, omega=%.3f)\n", s->theta_u, s->omega);
        }
    }
    
    // State machine
    switch (s->state) {
        case ST_IDLE: // IDLE
            u = 0.0f;
            // Don't automatically start swing-up - let user control it
            break;
            
        case ST_SWINGUP: { // SWINGUP - energy-based swing-up control with proactive braking
            // Track an unwrapped angle to detect full rotations and apply a
            // closed‑loop progressive brake, mirroring the PC simulator.  Use
            // the virtual encoder (ve) to integrate the angular velocity and
            // provide the unwrapped upright‑referenced angle.  The encoder is
            // updated here each control loop.  Static variables are used to
            // accumulate absolute motion and manage the progressive brake state.
            static float last_unwrapped = 0.0f;
            static float rotation_accum_u = 0.0f;
            static bool  prog_brake_active = false;
            static float prog_duty = 0.0f;
            static float prog_omega_prev = 0.0f;

            // Update the virtual encoder with the measured angular velocity and
            // integrate it forward by the control timestep.  The encoder
            // maintains an unwrapped angle internally, which can be used for
            // detecting full rotations even if theta_u is wrapped.
            ve_set_velocity(&ve, s->omega);
            ve_update(&ve, p->dt);

            // Retrieve the current unwrapped angle from the encoder.  This is
            // the angle from the upright reference (0 rad upright) without
            // wrapping into [−π, π].
            float current_unwrapped = ve_angle(&ve);

            // Accumulate the absolute change in unwrapped angle to detect
            // when a full rotation (2π) has occurred.  This mirrors the
            // logic in the PC simulator, which uses an unwrapped encoder
            // instead of the raw wrapped theta_u.  When rotation_accum_u
            // exceeds 2π, one full rotation has been detected.
            rotation_accum_u += fabsf(current_unwrapped - last_unwrapped);
            last_unwrapped = current_unwrapped;

            float abs_theta = fabsf(s->theta_u);
            float abs_omega = fabsf(s->omega);

            // Define revolution threshold for rotation detection
            const float REVOLUTION_THRESHOLD = 2.0f * (float)M_PI;      // ~6.28 rad/s (1 rev/s)

            // NOTE: Removed velocity-based emergency braking - anti-spin should only 
            // trigger after completing full rotations, not based on speed alone

            // Detect completion of a full rotation and engage progressive brake.  When a
            // full revolution (2π rad) has been accumulated and the speed is below
            // the emergency threshold, start a closed-loop deceleration sequence.
            // Disable progressive brake engagement during swing‑up.  The swing‑up
            // controller now relies on adaptive energy control and predictive
            // braking.  Guard this full‑rotation check with a constant false
            // expression to prevent progressive braking during normal swing‑up.
            // NOTE: Removed old progressive braking code - replaced with rotation-based anti-spin
            // that coasts down to target speed with light braking as needed

            // NOTE: Removed velocity-based graduated emergency braking
            // Anti-spin should only trigger after completing full rotations, not based on speed alone
            
            // ADVANCED ENERGY PREDICTION AND OVERSHOOT ESTIMATION SYSTEM
            // ================================================================
            
            // 1. APEX DETECTION AND CALIBRATION ON THE FLY
            // Detect zero-crossings of angular velocity to identify swing apexes
            float omega_sign = sgn(s->omega);
            s->apex_detected_this_cycle = false;
                
                if (s->last_omega_sign != 0.0f && omega_sign != s->last_omega_sign && fabsf(s->omega) < 2.0f) {
                    // Zero-crossing detected - we just reached an apex
                    s->apex_detected_this_cycle = true;
                    float current_apex_angle = fabsf(s->theta_u) * 180.0f / (float)M_PI; // Convert to degrees
                    
                    // Calibration: Compare actual apex with expected target (upright = 0°)
                    if (s->last_apex_angle > 0.0f) { // Have previous apex for comparison
                        float target_apex = 0.0f; // Target is upright
                        float apex_error = current_apex_angle - target_apex;
                        
                        // Adjust energy bleed gain based on overshoot/undershoot
                        if (apex_error > 5.0f) { // Overshooting by more than 5°
                            s->energy_bleed_gain *= 1.05f; // Increase bleeding slightly
                        } else if (apex_error < -5.0f) { // Undershooting by more than 5°
                            s->energy_bleed_gain *= 0.95f; // Decrease bleeding slightly
                        }
                        
                        // Clamp gain to reasonable bounds
                        s->energy_bleed_gain = fmaxf(0.5f, fminf(s->energy_bleed_gain, 2.0f));
                        
                        if (debug_is_output_enabled()) {
                            printf("APEX CALIBRATION: angle=%.1f°, error=%.1f°, gain=%.3f\n", 
                                   current_apex_angle, apex_error, s->energy_bleed_gain);
                        }
                    }
                    
                    s->last_apex_angle = current_apex_angle;
                }
                s->last_omega_sign = omega_sign;
                
                // 2. CONTINUOUS ROTATION DETECTION FOR SPIN-OUT PROTECTION
                // Track continuous rotations more intelligently
                static float last_wrapped_angle = 0.0f;
                float current_wrapped = wrap_pi(s->theta_u);
                float angle_delta = current_wrapped - last_wrapped_angle;
                
                // Detect when pendulum crosses ±π boundary (full rotation)
                if (fabsf(angle_delta) > M_PI) {
                    s->continuous_rotations++;
                    if (debug_is_output_enabled()) {
                        printf("CONTINUOUS ROTATION #%d detected\n", s->continuous_rotations);
                    }
                } else if (s->apex_detected_this_cycle && fabsf(s->omega) < 1.0f) {
                    // Reset rotation count when we detect a proper apex with low speed
                    s->continuous_rotations = 0;
                }
                last_wrapped_angle = current_wrapped;
                
                // 3. ENERGY RATIO AND OVERSHOOT PREDICTION
                float energy_ratio = (s->Edes > 1e-6f) ? (s->E / s->Edes) : 0.0f;
                
                // 4. ADAPTIVE BRAKING DUTY CALCULATION
                s->adaptive_brake_duty = 0.0f; // Reset
                
                if (energy_ratio > 1.02f) { // More than 2% over target
                    // Calculate exact energy to bleed off using motor torque-to-duty conversion
                    float excess_energy = s->E - s->Edes;
                    float excess_ratio = excess_energy / s->Edes;
                    
                    // Calculate braking torque needed to bleed off excess energy over one swing period
                    // Assume swing period ≈ 2π√(L/g) for small angles, scale for actual pendulum
                    float estimated_swing_period = 2.0f * (float)M_PI * sqrtf(p->L / 9.81f);
                    float energy_bleed_rate = excess_energy / estimated_swing_period; // Energy/time
                    
                    // Convert energy bleed rate to braking torque
                    // Power = Torque × Angular_velocity, so Torque = Power / Angular_velocity
                    float abs_omega_local = fabsf(s->omega);
                    if (abs_omega_local > 0.1f) {
                        float required_brake_torque = energy_bleed_rate / abs_omega_local;
                        
                        // Convert torque to motor duty using motor torque-to-duty conversion
                        s->adaptive_brake_duty = required_brake_torque / p->u_to_tau;
                        
                        // Apply calibrated energy bleed gain for fine-tuning
                        s->adaptive_brake_duty *= s->energy_bleed_gain;
                        
                        // Scale based on excess ratio - more excess = more braking
                        s->adaptive_brake_duty *= (1.0f + excess_ratio);
                        
                        // Clamp to reasonable braking limits (max 30% brake during energy pumping)
                        s->adaptive_brake_duty = fmaxf(0.0f, fminf(s->adaptive_brake_duty, 0.3f));
                        
                        if (debug_is_output_enabled()) {
                            printf("ENERGY OVERSHOOT PREDICTION: ratio=%.2f, excess=%.3fJ, brake_duty=%.3f\n",
                                   energy_ratio, excess_energy, s->adaptive_brake_duty);
                        }
                    }
                }
                
                // 5. ROTATION-BASED ANTI-SPIN PROTECTION
                // After completing full rotations, cut power and coast down with light braking
                bool true_spinout = (s->continuous_rotations >= SPINOUT_ROTATION_THRESHOLD);
                
                if (true_spinout) {
                    // Record peak speed when first detecting spin-out
                    static float spinout_peak_speed = 0.0f;
                    static bool spinout_active = false;
                    
                    if (!spinout_active) {
                        // First detection - record peak speed and start coasting
                        spinout_peak_speed = fabsf(s->omega);
                        spinout_active = true;
                        if (debug_is_output_enabled()) {
                            printf("ANTI-SPIN ACTIVATED: %d rotations, peak_ω=%.1f rad/s - COASTING DOWN\n",
                                   s->continuous_rotations, spinout_peak_speed);
                        }
                    }
                    
                    float current_speed = fabsf(s->omega);
                    float target_speed = spinout_peak_speed * ANTI_SPIN_COAST_TARGET_PERCENT;
                    
                    if (current_speed > target_speed) {
                        // Still above target speed - apply light braking to prevent energy buildup
                        u = -sgn(s->omega) * ANTI_SPIN_BRAKE_DUTY;
                        if (debug_is_output_enabled()) {
                            printf("ANTI-SPIN BRAKE: ω=%.1f/%.1f rad/s (%.0f%% of peak), brake=%.1f\n",
                                   current_speed, target_speed, (current_speed/spinout_peak_speed)*100, ANTI_SPIN_BRAKE_DUTY);
                        }
                    } else {
                        // Reached target speed - release anti-spin and reset
                        spinout_active = false;
                        spinout_peak_speed = 0.0f;
                        s->continuous_rotations = 0; // Reset rotation counter
                        u = 0.0f; // No command - let normal control resume
                        if (debug_is_output_enabled()) {
                            printf("ANTI-SPIN RELEASED: ω=%.1f rad/s (reached %.0f%% target) - RESUMING NORMAL CONTROL\n",
                                   current_speed, ANTI_SPIN_COAST_TARGET_PERCENT * 100);
                        }
                    }
                } else {
                    // Normal swing-up with adaptive braking during upswing
                    
                    // If we're within the catch zone and have accumulated at least 80% of
                    // the desired energy, apply light braking and transition to balance.
                    if (abs_theta < p->theta_catch && s->E >= ENERGY_CATCH_THRESHOLD * s->Edes) {
                        u = -sgn(s->omega) * p->brake_light;
                        if (debug_is_output_enabled()) {
                            printf("SWING-UP COMPLETE: theta=%.1f°, omega=%.1f rad/s, transitioning to BALANCE\n", 
                                   s->theta_u * 180.0f / (float)M_PI, s->omega);
                        }
                        s->state = ST_BALANCE;
                        ctrl_reset_integrator(s);
                        break;
                    } else {
                        // Continue energy pumping with adaptive braking overlay
                        u = energy_control(p, s);
                        
                        // 6. ADAPTIVE BRAKING DURING UPSWING
                        // Apply adaptive braking duty ON TOP of normal energy pump commands
                        // This ensures smooth energy bleed without fighting the pump
                        if (s->adaptive_brake_duty > 0.0f) {
                            // Calculate braking component that opposes current motion
                            float adaptive_brake_component = -sgn(s->omega) * s->adaptive_brake_duty;
                            
                            // Combine energy pump and adaptive brake using weighted sum
                            // Higher energy ratios get more braking influence
                            float brake_weight = fminf((energy_ratio - 1.02f) * 5.0f, 0.5f); // Max 50% brake influence
                            brake_weight = fmaxf(0.0f, brake_weight);
                            
                            // Weighted combination: mostly energy pump with adaptive brake overlay
                            u = u * (1.0f - brake_weight) + adaptive_brake_component * brake_weight;
                            
                            if (debug_is_output_enabled()) {
                                printf("ADAPTIVE BRAKE OVERLAY: pump=%.3f, brake=%.3f, weight=%.3f, final=%.3f\n",
                                       energy_control(p, s), adaptive_brake_component, brake_weight, u);
                            }
                        }
                    }
                } // End of spin-out check
            }
            break;
        }
        
        case ST_BALANCE: { // BALANCE - strengthened for better stability
            // Balance loss condition using configured catch thresholds for hysteresis
            if ((fabsf(s->theta_u) > p->theta_catch) || (fabsf(s->omega) > p->omega_catch)) {
                // NOTE: Removed purely speed-based emergency braking that was preventing normal swing-up
                // Anti-spin should only trigger after rotation completion, not based on speed alone
                
                // Switch directly to swing-up when balance is lost
                s->state = ST_SWINGUP;
                    if (debug_is_output_enabled()) {
                        // Removed debug arrows from message for clarity
                        printf("LOST BALANCE, switching to SWINGUP: theta=%.1f°, omega=%.1f rad/s\n",
                               s->theta_u * 180/M_PI, s->omega);
                    }
                }
                
                // Only switch to swing-up if speed is under control
                if (fabsf(s->omega) <= 3.0f) {
                    s->state = ST_SWINGUP;
                }
                break;
            }
            
            // Normal balance control - use PD controller for stability
            // CRITICAL FIX: Use wrapped theta_u for proper control
            float theta_u_wrapped = wrap_pi(s->theta_u);
            
            // **CORRECTED: Standard negative feedback for pendulum balancing**
            // For upright pendulum: u should oppose theta_u to restore equilibrium
            u = -p->Kp * theta_u_wrapped - p->Kd * s->omega;
            
            // Integrator for disturbance rejection  
            s->ui += p->Ki * theta_u_wrapped;
            s->ui = clampf(s->ui, -p->ui_max, p->ui_max);
            u += s->ui;
            
            // Apply balance saturation
            u = clampf(u, -p->balance_sat, p->balance_sat);
            
            break;
        }
    }
    
    // Apply saturation
    u = clampf(u, -1.0f, 1.0f);
    
    // SIMPLIFIED MOTOR INVERSION: Only apply MOTOR_INVERT flag, remove complex logic
    // This avoids double-inversion issues that cause "upside down" behavior
    if (MOTOR_INVERT) {
        u = -u;
    }
    // REMOVED: Complex sensor inversion compensation that was causing double inversion
    
    s->u = u;
    
    return u;
}

// Main control step function called from main.c
float ctrl_step(const ctrl_params_t *p, ctrl_state_t *s) {
    float u = ctrl_update((ctrl_params_t*)p, s);
    s->u = u;
    return u;
}
